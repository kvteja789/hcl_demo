import React from "react";
import AppHeader from "./components/AppHeader.js";
import ProductInfo from "./pages/ProductInfo.js";
import Cart from "./pages/Cart.js";
import './App.css';
import UserDetails from "./pages/UserDetails";
import UserRegistration from "./pages/UserRegistration";
import LoginScreen from "./pages/LoginScreen";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";

const App = () => {
  return (
    <Router>
        <AppHeader />
        <Switch>
          <Route path="/cart"><Cart /></Route>
          <Route path="/userdetails"><UserDetails /></Route> 
          <Route path="/userRegistration"><UserRegistration /></Route>
          <Route path="/productInfo"><ProductInfo /></Route>
          <Route path="/"><LoginScreen /></Route>
        </Switch>
    </Router>
  );
}
export default App;

