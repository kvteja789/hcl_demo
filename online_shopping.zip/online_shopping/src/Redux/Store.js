import {createStore,combineReducers,applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import loginReducer from './Reducers/LoginReducer';
//import collesListReducer from './Reducers/CollegesListReducer';
//import applyAdmissinReducer from './Reducers/ApplyForAdmissionReducer'

const rootReducer = combineReducers({
    login: loginReducer
})
const store = createStore(rootReducer,applyMiddleware(thunk)); 
export default store;