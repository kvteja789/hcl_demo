const validateCredentials = (users, user_creds) => {
  let obj = {
    user_name: '',
    is_error: false,
    is_login: false
  };
  users.find((val) => {
    if ((val.name === user_creds.name) && (val.password === user_creds.password)) {       
      obj.is_error = false;
      obj.is_login = true;
      obj.user_name = val.name;
    }
    else if (obj.is_login === false) {
      obj.is_error = true;
      obj.is_login = false;
    }
  });
  return obj;
};
export default validateCredentials;




