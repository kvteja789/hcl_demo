import React,{useEffect,useState} from "react";
import { Link } from "react-router-dom";
import axios from 'axios';
import { makeStyles } from '@material-ui/core/styles';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { useCart } from "../context/myContext";
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import Badge from '@material-ui/core/Badge';
import { connect } from 'react-redux';
import Button from '@material-ui/core/Button';
import { logout } from '../Redux/Actions/LoginAction'; 
import { useHistory } from 'react-router-dom';


const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1
  },
  title: {
    flexGrow: 1,
    textAlign:'center'
  },
  elementContainer: {
    color: 'white',
    margin:5,
    textDecoration:'none'

  }
}));

const AppHeader = (props) => {
  const history = useHistory();
  const [cartCount,setCartCount] = useState(0);
  useEffect(() => {
    getCartData();  
  }, []);

  //get cart details from db.json using axios
  const getCartData = async () =>{
    await axios.get(`http://localhost:3000/addToCart`).then((res) => {
      res && res.data && setCartCount(res.data.length);
    });
  }

  const doLogout = () => {
    history.push('/');
    props.logout();
  }
  const cart = useCart(); 
  const login_status = props.isLogin;
  const user_name = props.userDetails && props.userDetails.user_name;
  const items = (cart.length ===0) ? cartCount : cart && cart.products && cart.products.length;
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <AppBar position="static" color="secondary" style={{ backgroundColor: '#563a86' }}>
        <Toolbar>
        {login_status ? null:<Typography><Link className={classes.elementContainer} to="/userRegistration">
            Registration
         </Link></Typography>}
         {login_status ? 
          <Typography><Link className={classes.elementContainer} to="/">
            Product List
         </Link></Typography>:null}
          <Typography variant="h6" className={classes.title}>
          Online Shopping 
          </Typography>    
          {login_status ? null:<Typography><Link className={classes.elementContainer} to="/">
            Login
         </Link></Typography>}
         {login_status ? 
         <>
          <Typography><div className={classes.elementContainer}>User : {user_name}</div></Typography>
          <Link className={classes.elementContainer} to='/cart'>
            <Badge anchororigon={{ vertical: 'top', horizontal: 'left' }} badgeContent={items} color="primary">
              <ShoppingCartIcon />
            </Badge>
          </Link>
          <Typography><Button className={classes.elementContainer} onClick={doLogout}>Logout</Button></Typography>
          </>          
          : null}
        </Toolbar>
      </AppBar>
    </div>
  );
};
const mapStateToProps = state => {
  return {
    userDetails: state.login.userDetails,
    isLogin: state.login.is_login
  }
}
const mapDispatchToProps = dispatch => {
  return {
    logout: () => dispatch(logout()),
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(AppHeader);



