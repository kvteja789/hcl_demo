import React from "react";
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Typography from '@material-ui/core/Typography';
import CardActions from '@material-ui/core/CardActions';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles({
  card: {
    maxWidth: 250,
    display: 'flex',
    padding: 20,
    margin: 10,
    alignItems: 'center',
    float: 'left',
    flexDirection: 'column'
  },
  media: {
    height: 100,
  },
  noData: {
    textAlign: 'center',
    margin: 'auto',
    marginTop: 20
  }
});

const CardLayout = ({ product, index, handleRemove ,buttonHandler ,addToCart}) => {
  const classes = useStyles();
  return (
    <>
      <Card className={classes.card} key={product.id}>
        <CardActionArea>
          <CardMedia
            className={classes.media}
            image={product.img}
            title="Contemplative Reptile"
          />
          <CardContent>
            <Typography gutterBottom component="h5">
              Brand: {product.brand}
            </Typography>
            <Typography variant="body2" color="textSecondary" component="p">
              Price: {product.price}
            </Typography>
          </CardContent>
        </CardActionArea>
        <CardActions>
         {buttonHandler?(<Button onClick={() => handleRemove(index)} size="small" color="primary">
          Remove from cart
          </Button>):(
          <Button onClick={() => addToCart(product)} size="small" color="primary">
            Add to cart
          </Button>)} 
        </CardActions>
      </Card>
    </>
  );
}
export default CardLayout;
