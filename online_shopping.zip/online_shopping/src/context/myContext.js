import React, { useReducer, useContext, createContext } from "react";
import reducer  from "../store/reducer";

const CartStateContext = createContext();
const CartDispatchContext = createContext();

 const GlobalProvider = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, []);
  return (
    <CartDispatchContext.Provider value={dispatch}>
      <CartStateContext.Provider value={state}>
        {children}
      </CartStateContext.Provider>
    </CartDispatchContext.Provider>
  );
};
export default GlobalProvider;

export const useCart = () => useContext(CartStateContext);
export const useDispatchCart = () => useContext(CartDispatchContext);
