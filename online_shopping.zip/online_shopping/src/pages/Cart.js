import React,{useState,useEffect} from "react";
import axios from 'axios';
import { useCart, useDispatchCart } from "../context/myContext";
import  CardLayout from "../components/CardLayout";
import CardActions from '@material-ui/core/CardActions';
import { useHistory } from 'react-router-dom';
import AlertDialog from "../components/AlertDialog";
import Button from '@material-ui/core/Button';

 const Store = () =>{
  const history = useHistory();
  const [cartData,setCartData] = useState([]);
  useEffect(() => {
    getCartData();  
  }, []);

  const [open, setOpen] = useState(false);
  const [productId, setProductId] = useState();

  const showConfirmationDialog = () => {
    setOpen(true);
  };

  const removeItemFromCart = async () => {
    await axios.delete(`http://localhost:3000/addToCart/${productId}`);
    loadCartList();
    setOpen(false);
  };
  const handleClose = () => {
    setOpen(false);
  };
  
  //get cart details from db.json using axios
  const getCartData = async () =>{
    await axios.get(`http://localhost:3000/addToCart`).then((res) => {
      res && res.data && setCartData(res.data);    
    });
  }

  const cart = useCart();
  const items = (cart.length ===0) ? cartData : cart && cart.products;

  const dispatch = useDispatchCart();
  const totalPrice = items.reduce((total, b) => total + b.price, 0);

  //handler to remove item from cart
  const handleRemove = async (id) => {
    setProductId(id);
    showConfirmationDialog();
  }
  
 // load cart list
  const loadCartList = async () =>{
    await axios.get(`http://localhost:3000/addToCart`).then((res) => {
      dispatch({ type: "REMOVE", payload:res.data });
    }).catch((err) =>{
      console.log('something went wrong-',err);
    })
  }

  const userDetails = () =>{
    history.push({
      pathname: '/userdetails'
    })
  }

  if (items.length === 0) return <p style={{textAlign:'center'}}>Cart is empty</p>    
  return (
    <>
        {items.map((item, index) => (
          <CardLayout
            buttonHandler = {true}
            handleRemove={handleRemove}
            key={index}
            product={item}
            index={item.id}
          />
        ))}
      <div style={{position:"fixed",right:0,bottom:50,left:1100}}>
        <p>Total price {totalPrice}/-</p>
        <CardActions>
        <Button variant="contained" onClick={userDetails} style={{ backgroundColor: '#563a86' }}  size="small" color="primary">
            place order
        </Button>
        </CardActions>
      </div>
      <AlertDialog title="Do you want to delete item from cart?" btnText='ok' btnCancel="cancel" close={handleClose} open={open} handleClose={removeItemFromCart} />
      </>
  );
}
export default Store;
