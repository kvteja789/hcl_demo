import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { useDispatchCart } from "../context/myContext";
import CardLayout from "../components/CardLayout";
import AlertDialog from '../components/AlertDialog';

const ProductInfo = (props) => {

    const [productList,setProductList] = useState([]);
    const [open, setOpen] = React.useState(false);
    const handleClickOpen = () => {
      setOpen(true);
    };
    const handleClose = () => {
      setOpen(false);
    };

    useEffect(() => {
      loadProductList();  
    }, []);

    const dispatch = useDispatchCart();
    
    //handler to add product to cart
    const addToCart = async (item) => {
      await axios.post("http://localhost:3000/addToCart",{...item,id:Math.floor(Math.random() * 1000)});
      loadCartList();    
    };

    //load cart list
    const loadCartList = async () =>{
      await axios.get(`http://localhost:3000/addToCart`).then((res) => {
        dispatch({ type: "ADD", payload:res.data });
        handleClickOpen();
      }).catch((err) =>{
        console.log('something went wrong-',err);
      });
    }

    //get product list from db.json using axios
    const loadProductList = async () =>{
      await axios.get(`http://localhost:3000/productinfo`).then((res) => {
          setProductList([...res.data]);
      });     
    }
    
  return (
    <>
      {productList.map((product,index) => (
        <CardLayout
          buttonHandler = {false}
          addToCart={addToCart}
          key={index}
          product={product}
          index={product.id}
       />
      ))}
      <AlertDialog title="Your Item is added to cart" btnText='ok' open={open} handleClose={handleClose} />
    </>
  );
}
export default ProductInfo;
