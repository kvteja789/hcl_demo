import React, { useState } from 'react';
import axios from 'axios';
import Button from '@material-ui/core/Button';
import { Grid, Paper } from '@material-ui/core';
import {  TextField } from '@material-ui/core';
import { useHistory } from 'react-router-dom';
import { useCart, useDispatchCart } from "../context/myContext";
import { useFormik } from 'formik';
import Typography from '@material-ui/core/Typography';
import AlertDialog from "../components/AlertDialog";


const UserDetails = (props) => {
    const history = useHistory();
    const paperStyle = { padding: 20, height: '47vh', width: 250, margin: '70px auto', }
    const container = { width:'100%',height:'90%'}
    const error = { color:'red'}
    const [details, setDetails] = useState({cardnumber: '',name: '',expiry:'',password:''});

    const cart = useCart();
    const dispatch = useDispatchCart();
    const [open, setOpen] = React.useState(false);
    
    const handleClickOpen = () => {
      setOpen(true);
    };
    const handleClose = () => {
      setOpen(false);
    };

    const formik = useFormik({
        initialValues: { //managing form state data
            cardnumber: '',
            name: '',
            expiry: '',
            password: ''
        },
        onSubmit: values => {
            console.log(JSON.stringify(values));
            //handleClickOpen();
            dispatch({ type: "REMOVE_CART_DATA", payload:[]});
            history.push('/');
        },
        validate: values => {
            let errors = {};
            if (!values.cardnumber) {
                errors.cardnumber = "Card number is required";
            }
            if (!values.name) {
                errors.name = "Name is required";
            }
            if (!values.expiry) {
                errors.expiry = "Year of expiry is required";
            }
            if (!values.password) {
                errors.password = "Password is required";
            }
            return errors;
        }
    });
    const loadCartList = async () =>{
        await axios.get(`http://localhost:3000/addToCart`).then((res) => {
            dispatch({ type: "REMOVE_CART_DATA", payload:res.data });
        }).catch((err) =>{
          console.log('something went wrong-',err);
        })
    }
    return (
        <div style={container}>
            <Grid>
                <form onSubmit={formik.handleSubmit}> 
                    <Paper style={paperStyle} align='center'>
                        <Typography><Grid><h4>Enter Your Details</h4></Grid></Typography>
                        <TextField type="number" label="Card number" id="cardnumber" name="cardnumber" onChange={formik.handleChange} 
                        onBlur={formik.handleBlur} value={formik.values.cardnumber} />
                        {formik.touched.cardnumber && formik.errors.cardnumber ? <div style={error}>{formik.errors.cardnumber}</div> : null}
                        
                        <TextField type="text" label="Name on the card" id="name" name="name" onChange={formik.handleChange} 
                        onBlur={formik.handleBlur} value={formik.values.name} />
                        {formik.touched.name && formik.errors.name ? <div style={error}>{formik.errors.name}</div> : null}
       
                        <TextField type="number" label="Card expiry year" id="expiry" name="expiry" onChange={formik.handleChange} 
                        onBlur={formik.handleBlur} value={formik.values.expiry} />
                        {formik.touched.expiry && formik.errors.expiry ? <div style={error}>{formik.errors.expiry}</div> : null}
       
                        <TextField type="text" label="3d secure password" id="password" name="password" onChange={formik.handleChange} 
                        onBlur={formik.handleBlur} value={formik.values.password} />
                        {formik.touched.password && formik.errors.password ? <div style={error}>{formik.errors.password}</div> : null}                       
                        <br></br><br></br>
                        <Button style={{ backgroundColor: '#563a86' }} variant="contained" type="submit" color="primary">pay</Button>
                    </Paper>
                </form>
            </Grid>
            <AlertDialog title="Order placed successfully" btnText='ok' open={open} handleClose={handleClose} />
        </div>
    )
}
export default UserDetails;