import React from 'react'
import { Grid, Paper, Button, Typography } from '@material-ui/core'
import { TextField } from '@material-ui/core'
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import AlertDialog from "../components/AlertDialog";

const UserRegistration = () => {
    const paperStyle = { padding: '40px 20px', width: 250, margin: '20px auto' };
    const [open, setOpen] = React.useState(false);
    const handleClickOpen = () => {
      setOpen(true);
    };
    const handleClose = () => {
      setOpen(false);
    };
    const btnStyle = { marginTop: 10 }
    const initialValues = {
        fname: '',
        lname: '',
        email: '',
        phoneNumber: '',
        password: '',
        gender:''
    }
    const validationSchema = Yup.object({
        fname: Yup.string().min(3, "It's too short").required("Required"),
        lname: Yup.string().min(3, "It's too short").required("Required"),
        email: Yup.string().email("Enter valid email").required("Required"),
        phoneNumber: Yup.number().typeError("Enter valid Phone number").required("Required"),
        password: Yup.string().min(8, "Minimum characters should be 8").required('Required')
    })
    const onSubmit = (values, props) => {
        handleClickOpen();
        props.resetForm()
    }
    return (
        <>
            <Grid>
                <Paper elevation={10} style={paperStyle} align='center'>
                    <Grid>
                        <Typography variant='h6'>Register Here</Typography>
                    </Grid>
                    <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
                        {(props) => (
                            <Form>
                                <Field as={TextField} name='fname' label='First Name' fullWidth
                                    error={props.errors.fname && props.touched.fname}
                                    helperText={<ErrorMessage name='fname' />} required />
                                <Field as={TextField} name='lname' label='Last Name' fullWidth
                                    error={props.errors.lname && props.touched.lname}
                                    helperText={<ErrorMessage name='name' />} required />
                                <Field as={TextField} name='email' label='Email' fullWidth
                                    error={props.errors.email && props.touched.email}
                                    helperText={<ErrorMessage name='email' />} required />

                                <Field as={TextField} name="phoneNumber" label='Phone Number' fullWidth
                                    error={props.errors.phoneNumber && props.touched.phoneNumber}
                                    helperText={<ErrorMessage name='phoneNumber' />} required />

                                <Field as={TextField} name='password' label='Password' type='password' fullWidth
                                    error={props.errors.password && props.touched.password}
                                    helperText={<ErrorMessage name='password' />} required /><br/>

                                <div id="my-radio-group">Gender</div><br/>
                                <div role="group" aria-labelledby="my-radio-group">
                                    <label><Field type="radio" name="gender" value="Male" />Male</label>
                                    <label style={{marginLeft:10}}><Field type="radio" name="gender" value="Female" />Femal</label>
                                </div>
                                <Button style={{ backgroundColor: '#563a86' }} type='submit' style={btnStyle} variant='contained'
                                    color='primary'>Register</Button>
                            </Form>
                        )}
                    </Formik>
                </Paper>
            </Grid>
            <AlertDialog title="Registration success" btnText='ok' open={open} handleClose={handleClose} />
        </>
    )
}

export default UserRegistration;