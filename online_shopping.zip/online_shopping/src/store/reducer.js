const initialState = {
  products:[]
}

//reducer to remove and add cart from store
const reducer = (state = initialState, action) => {
    switch (action.type) {
      case "ADD":
        return{
          ...state,
          products:action.payload
        }
      case "REMOVE":
        return{
          ...state,
          products:action.payload
        }

        case "REMOVE_CART_DATA":
          return{
            ...state,
            products:action.payload
          }

      default:
        throw new Error(`unknown action ${action.type}`);
    }
};

export default reducer;
  